package com.b97.employeedetailsreport.client;
import com.cts.employeedetailsreport.skeleton.SkeletonValidator;

public class EmployeeDetailsMain {

	public static void main(String[] args) {
		// CODE SKELETON - VALIDATION STARTS
		// DO NOT CHANGE THIS CODE

		new SkeletonValidator();
		
		// CODE SKELETON - VALIDATION ENDS

// TYPE YOUR CODE HERE
	}

	}

