package com.b97.employeedetailsreport.dao;

import java.sql.Connection;

import java.util.List;

import com.cts.employeedetailsreport.exception.InvalidEmployeeNumberException;
import com.cts.employeedetailsreport.model.EmployeeDetails;


public class DetailsDAO {
	
	
	public boolean insertEmployeeList(List <EmployeeDetails> eList) throws InvalidEmployeeNumberException {
	
		boolean recordsAdded = false;
		
		// FILL THE CODE HERE

		
		return recordsAdded;
	}
	    		
	    
	    	
}
