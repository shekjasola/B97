package com.b97.employeedetailsreport.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.employeedetailsreport.exception.InvalidEmployeeNumberException;
import com.cts.employeedetailsreport.model.EmployeeDetails;

public class HospitalManagement {
	
	
public static ArrayList <EmployeeDetails> buildEmployeeList(List <String> employeeRecords) {
		
		
		final String COMMADELIMITER = ",";
		ArrayList <EmployeeDetails> empList = new ArrayList<EmployeeDetails>();
		
    	//fill the code here
 	 	
		return empList;
	}
	
	
	
	public boolean addEmployeeList(String inputFeed) throws InvalidEmployeeNumberException
	{
    	//fill the code here

		return false;
	}
	
	

	public static double calculateTotalSalary(String level,int extraWorkingHours)
    {
		double sal=0.0;
    	//fill the code here

		return sal;
    }
    

}
