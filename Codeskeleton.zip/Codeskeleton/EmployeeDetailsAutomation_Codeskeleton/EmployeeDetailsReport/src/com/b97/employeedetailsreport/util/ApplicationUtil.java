package com.b97.employeedetailsreport.util;


import java.util.ArrayList;
import java.util.List;

import com.cts.employeedetailsreport.exception.InvalidEmployeeNumberException;

public class ApplicationUtil {
	 public static List<String> readFile(String filePath) 
	    {
	    	List<String> employeeList=new ArrayList<String>();
	    	
			// FILL THE CODE HERE

	    	return employeeList
	    	
	    }
	    public static boolean validate(String employeeNumber) throws InvalidEmployeeNumberException
		{
	    	boolean val=false;
			// FILL THE CODE HERE

	    	return val;
	    	
	    		

		}


}
