package com.b97.loanrms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;


import com.cts.loanrms.dao.LoanInstallmtDAO;
import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.util.ApplicationUtil;



public class LoanRepaymentService {

	LoanInstallmtDAO loanInstallmentDAO = new LoanInstallmtDAO();
	public static ArrayList <LoanInstallmentPyt> buildLoanInstallmentPytList(List <String> loanInstPytRecords) {
		
		
		final String COMMADELIMITER = ",";
		ArrayList <LoanInstallmentPyt> loanInstPytList = new ArrayList<LoanInstallmentPyt>();
		
		// TYPE YOUR CODE HERE
		
		return loanInstPytList;
	}
	
	public boolean addLoanInstallmentPytDetails(String inputFeed) throws LoanRepaymentException {
	
		
		// TYPE YOUR CODE HERE
		
			return false;
	}
	public static double calculateDiscountedInstallment(String loanType,double loanAmount,double currentInstallmentAmt) {
		double revisedInstallmentAmt=0.0;
		
		// TYPE YOUR CODE HERE
		
		return Math.round(revisedInstallmentAmt);
	}
	
	
}
