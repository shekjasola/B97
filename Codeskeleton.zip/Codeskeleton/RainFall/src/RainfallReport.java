import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RainfallReport {
    /**
     * This method should validate the city pincode,
     * if valid return true
     * else this method should throw an userdefined exception
     *
     * @param cityPincode Pin code of a city
     * @return true if valid pincode
     * @throws InvalidCityPincodeException is thrown if pincode is invalid (must only consist of 5 digits)
     */
    public boolean validate(String cityPincode) throws InvalidCityPincodeException {
        
        }
    }

    /**
     * Generate a list of AnnualRainfall by retrieving data from a file
     *
     * @param filePath path to the file where data is stored
     * @return List of AnnualRainfall
     * @see AnnualRainfall
     */
    public List<AnnualRainfall> generateRainfallReport(String filePath) {
        List<AnnualRainfall> annualRainfallList = new ArrayList<>();

        

        return annualRainfallList;
    }

    /**
     * This method should extract all the AnnualRainfall details from
     * the AnnualRainfall table and
     * return the list of cities with maximum averageAnnualRainfall.
     *
     * @return List of AnnualRainfall
     * @see DBHandler
     * @see AnnualRainfall
     */
    public List<AnnualRainfall> findMaximumRainfallCities() {
        List<AnnualRainfall> maximumRainfallCities = new ArrayList<>();

        

        return maximumRainfallCities;
    }
}
