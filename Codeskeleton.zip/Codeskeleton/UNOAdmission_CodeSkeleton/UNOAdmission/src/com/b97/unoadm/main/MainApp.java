package com.b97.unoadm.main;

import com.cts.unoadm.skeletonvalidator.SkeletonValidator;

public class MainApp {

	public static void main(String[] args) {
		//Don't delete this code
		//Skeletonvalidaton starts
		new SkeletonValidator();
		//Skeletonvalidation ends

		//Write your code here..
		
		
	}

}
