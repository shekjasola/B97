create database HolidayPackage;
create table Package_Details(package_id varchar(25), source_place varchar(25), destination_place varchar(25), no_of_days int, package_cost int);