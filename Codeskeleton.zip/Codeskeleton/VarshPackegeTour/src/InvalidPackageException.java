
public class InvalidPackageException  extends Exception{
	public InvalidPackageException()
	{
		
	}

}
