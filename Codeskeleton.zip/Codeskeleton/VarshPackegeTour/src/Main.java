import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

import java.sql.PreparedStatement;

public class Main {
	public static void main(String[] args)
	{
		DBHandler db1=new DBHandler();
		//db1.estabilishConnection();
		TravelAgency tag=new TravelAgency();
		
		
	}

}
