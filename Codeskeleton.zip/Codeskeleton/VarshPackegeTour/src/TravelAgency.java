import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TravelAgency {

	List<Package> generatePackageCost(String filePath)
	{
		

			}
			
		
		
		
	
	boolean validate(String packageId)throws InvalidPackageException
	{
		
		return false;
		
	}
	
	List<Package> findPackagesWithMinimunNumberOfDays()
	{
		
		return packageList;
	}
}
