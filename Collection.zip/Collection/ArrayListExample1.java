package com.cts.coll2;

import java.util.*;

public class ArrayListExample1 {
	public static void main(String args[]) {
		LinkedList<String> list = new LinkedList<String>();// Creating arraylist
		list.add("Mango");// Adding object in arraylist
		list.add("Apple");
		list.add("Banana");
		list.add(2,"Grapes");
		
		
		// Printing the arraylist object
		System.out.println(list);
	}
}