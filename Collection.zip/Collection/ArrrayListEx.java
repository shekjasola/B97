package com.cts.coll2;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class ArrrayListEx {

	public static void main(String[] args) {
		
		SortedSet<String> l1 = new TreeSet<String>();
		
		l1.add("Orange");//0
		//l1.addFirst("PineApple");
		l1.add("Mango");//1
		l1.add("Mango");//1
		l1.add("Apple");//2
		//l1.add(null);//1
		//l1.add(null);//1
		//l1.addLast("Banana");
		//l1.add(3, "Grapes");
		//l1.pop();
		//l1.add(null);
		
		//System.out.println(l1);
		//class
		//Collections.reverse(l1);
		//System.out.println("After reverse "+ l1);
		
		Iterator<String> i1= l1.iterator();
		while(i1.hasNext()) {
			System.out.println(i1.next());
		}
		
		
		
		

	}

}
