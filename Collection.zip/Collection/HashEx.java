package com.cts.coll2;



import java.util.SortedMap;
import java.util.TreeMap;

public class HashEx {

	public static void main(String[] args) {
		SortedMap<Integer,String> map=new TreeMap<Integer,String>();  
	    //Adding elements to map  
	    map.put(1,"Amit");  
	    map.put(5,"Rahul");  
	    map.put(2,"Jai");  
	    map.put(6,"Amit"); 
	    map.put(7,null);
	    map.put(8,null);
	    
	    System.out.println(map);

	}

}
