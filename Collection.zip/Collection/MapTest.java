package com.cts.coll2;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapTest {

	public static void main(String[] args) {
		
		Map<Integer, String> m1= new TreeMap<Integer, String>();
		
		m1.put(9, "A");
		m1.put(2, "B");
		m1.put(12, "A");
		m1.put(4, "D");
		//m1.put(null, "E");
		System.out.println(m1);

	}

}
