package com.cts.coll2;

import java.util.*;

public class Mapex_main {

	public Map<String, String> getStudentdetails() {
		Map<String, String> studentmap = new HashMap<String, String>();
		studentmap.put("1", "mounika");
		studentmap.put("2", "sai");
		studentmap.put("3", "kiran");
		return studentmap;

	}

	public static void main(String[] args) {

		Mapex_main m1 = new Mapex_main();
		Map<String, String> studentdetails = m1.getStudentdetails();
		//System.out.println(studentdetails);
		Set<String> k1 = studentdetails.keySet();

		Iterator<String> ite = k1.iterator();
		
		while (ite.hasNext()) {
			String rollNo = ite.next();
			String name = studentdetails.get(rollNo);
			System.out.println("roll no " + rollNo + " name " + name);
		}

	}
}
