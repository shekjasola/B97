package ppt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class ArrayListDemo {

	public static void main(String[] args) {
		TreeMap<Integer,String>h1= new TreeMap<Integer,String>();
		h1.put(12, "Apple");
		h1.put(2, "Orange");
		h1.put(1, "Mango");
		h1.put(4, "Grapes");
		System.out.println(h1);
	

	}

}
