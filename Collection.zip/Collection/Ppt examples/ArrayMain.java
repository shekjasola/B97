package ppt;

import java.util.ArrayList;
import java.util.List;

public class ArrayMain {

	public List getCountryList(String s1, String s2, String s3, String s4, String s5) {

		List countryList = new ArrayList();

		countryList.add(s1);
		countryList.add(s2);
		countryList.add(s3);
		countryList.add(s4);
		countryList.add(s5);

		return countryList;

	}

	public List get1To10() {

		List l1 = new ArrayList();

		for (int i = 0; i <= 10; i++) {
			l1.add(i);

		}
		return l1;
	}

	public List get1To15(List l11) {

		List l2 = new ArrayList();

		l2.addAll(l11);

		for (int i = 11; i <= 15; i++) {
			l2.add(i);

		}
		return l2;
	}

	public static void main(String[] args) {

		ArrayMain a1 = new ArrayMain();

		System.out.println(a1.getCountryList("India", "Australia", "England", "South Africa", "New Zealand"));
		List l3 = a1.get1To10();
		
		System.out.println(l3);// 1-10
		
		System.out.println(a1.get1To15(l3));// 11-15
	}

}
