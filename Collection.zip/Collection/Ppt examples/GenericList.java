package ppt;

import java.util.ArrayList;
import java.util.List;

public class GenericList {

public List<String> getCountryList(String s1,String s2,String s3,String s4,String s5) {
		
		List <String>countryList= new ArrayList<String>();
		countryList.add(s1);
		countryList.add(s2);
		countryList.add(s3);
		countryList.add(s4);
		countryList.add(s5);
		
		return countryList;
		
	}
	
	public List<Integer> get1To10() {
		List<Integer>l1= new ArrayList<Integer>();
		for(int i=0;i<=10;i++) {
			l1.add(i);
			
		}
		return l1;
	}

	public List<Integer> get1To15(List l1) {
		List<Integer> l2= new ArrayList<Integer>();
		l2.addAll(l1);
		for(int i=11;i<=15;i++) {
			l2.add(i);
			
		}
		return l2;
	}
	public static void main(String[] args) {
		GenericList gl= new GenericList();
		System.out.println(gl.getCountryList("Indiia", "Australia", "England", "South Africa", "New Zealand"));
        List l3=gl.get1To10();
        System.out.println(l3);
        System.out.println(gl.get1To15(l3));

	}

}
