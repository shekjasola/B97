package ppt;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetMain {

public Set getCountry(String s1,String s2,String s3,String s4,String s5) {
		
		Set countryList= new HashSet();
		
		countryList.add(s1);
		countryList.add(s2);
		countryList.add(s3);
		countryList.add(s4);
		countryList.add(s5);
		
		return countryList;
		
	}
	
	public Set get1To10() {
		
		Set s1= new HashSet();
		
		for(int i=0;i<=10;i++) {
			s1.add(i);
			
		}
		return s1;
	}

	public Set get1To15(Set s11) {
		
		Set s2= new HashSet();
		
		s2.addAll(s11);
		
		for(int i=11;i<=15;i++) {
			s2.add(i);
			
		}
		return s2;
	}
	public static void main(String[] args) {
		SetMain a1= new SetMain();
		
		System.out.println(a1.getCountry("Indiia", "Australia", "England", "South Africa", "New Zealand"));
        Set s3=a1.get1To10();
        
        System.out.println(s3);
        
        System.out.println(a1.get1To15(s3));

	}

}
