package com.cts.aggregation;

class Operation {
	int square(int n) {
		return n * n;
	}
}