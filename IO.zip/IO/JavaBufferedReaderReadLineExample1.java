package com.cts.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class JavaBufferedReaderReadLineExample1 {

	public static void main(String[] args) throws IOException {
		FileReader f = new FileReader("c:\\shekhar\\infomarch7.txt");
		BufferedReader b = new BufferedReader(f);
		System.out.println(b.readLine());
		b.close();
		f.close();

	}
}