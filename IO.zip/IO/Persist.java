package com.cts.io;

import java.io.*;

class Persist {
	public static void main(String args[]) throws IOException {
	
			// Creating the object
			Student s1 = new Student(121, "Ravi");
			// Creating stream and writing the object
			FileOutputStream fout = new FileOutputStream("c:\\shekhar\\infoserializable.txt");
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(s1);
			out.flush();
			// closing the stream
			out.close();
			System.out.println("success");
		
	}
}