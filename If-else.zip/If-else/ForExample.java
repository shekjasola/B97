package com.cts.basics;

public class ForExample {
	public static void main(String[] args) {
		// Code of Java for loop
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		}
	}
}