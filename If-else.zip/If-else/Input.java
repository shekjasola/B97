import java.util.Scanner;

public class Input {

	public static void main(String[] args) {
		
		Scanner s1= new Scanner(System.in);
		
		
		System.out.println("Enter Name ");
		String name = s1.nextLine();
		
		System.out.println("Enter your Age");
		int age= s1.nextInt();
		
		System.out.println("The name of employee is "+ name +"  "+"Age is "+ age);
		
		s1.close();

	}

}
