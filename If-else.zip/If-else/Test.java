
public class Test {

	int x, y;

	public Test(int x1, int y1) {
		super();
		x = x1;
		y = y1;
	}
	
	public void display() {
		System.out.println(x+y);
	}

	public static void main(String[] args) {

		Test t1 = new Test(20,50);
		t1.display();

	}

}
