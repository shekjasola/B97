package com.cts.jdbc;

//step-1
import java.sql.*;

class MysqlCon {
	public static void main(String args[]) {
		try {
			//Step-2 java.lang.Class--register the driver
			//classNotFoundException
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//step-3--establish the connection
			//SQLException
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
            System.out.println(con);
			//step-4 create statement
			Statement stmt = con.createStatement();
			
			//step-5 -execute the query
			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
			//step-6
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}