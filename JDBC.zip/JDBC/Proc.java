package com.cts.jdbc;

import java.sql.*;

public class Proc {
	public static void main(String[] args) throws Exception {

		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "cts", "cts");

		CallableStatement stmt = con.prepareCall("{call insertR2(?,?)}");
		
		stmt.setInt(1, 105);
		stmt.setString(2, "Vijay");
		stmt.execute();

		System.out.println("success");
	}
}

/**

create or replace procedure "INSERTR2"  
(id IN NUMBER,  
name IN VARCHAR2)  
is  
begin  
insert into user values(id,name);  
end;  
**/