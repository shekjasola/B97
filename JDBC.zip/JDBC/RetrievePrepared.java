package com.cts.jdbc;

//step-1
import java.sql.*;

class RetrievePrepared {
	public static void main(String args[]) throws ClassNotFoundException {

		Connection con = null;
		//Statement stmt = null;
		ResultSet rs = null;
		try {
			// step-2 Registration
			Driver driver = new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(driver);

			String url = "jdbc:oracle:thin:@localhost:1521:xe";

			// Class.forName("oracle.jdbc.driver.OracleDriver");
			// Step-3 Establish Connection
			con = DriverManager.getConnection(url, "cts", "cts");
			System.out.println(con);
			
			String sql = "select * from emp";
			//stmt = con.createStatement();
			 PreparedStatement stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				System.out.println("Employee Id :" + rs.getInt(1));
				System.out.println("First Name :" + rs.getString(2));
				System.out.println("Last Name :" + rs.getString(3));
				System.out.println("========================");

			}

			//con.close();

		} catch (SQLException e) {
			System.out.println(e);
		}

		finally {
			try {
				con.close();
				//stmt.close();
				rs.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}