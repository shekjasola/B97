package com.cts.jdbc;

import java.sql.*;

public class Type4 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		
		//CRUD 
		ResultSet rs = null;
		Connection con = null;
		Statement stmt = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Class.forName("oracle.jdbc.driver.OracleDriver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");

			// con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
			// "cts", "cts");
			System.out.println(con);
              //CRUD
			// creating a table
			String sql1 = "create table emp7(id int,name varchar(24))";

			// Insert
			String sql2 = "insert into  emp7 values(1,'shek')";

			// Update
			String sql3 = "update emp7 set name='k' where id=1";

			// Delete
			String sql4 = "delete from emp7 where id=1";

			stmt = con.createStatement();
			
		     //stmt.executeUpdate(sql1);
			// stmt.executeUpdate(sql2);
		     // stmt.executeUpdate(sql3);
			stmt.executeUpdate(sql4);
			
			
			System.out.println("operation successfull!!!");

			// retrieving data from table

			rs = stmt.executeQuery("select * from emp7");
			while (rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));

			}

		} catch (Exception m) {
			System.out.println("Exception");
		}

		
	}
}
