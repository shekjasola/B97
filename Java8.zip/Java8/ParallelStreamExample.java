package com.cts.ps;
// Java code to demonstrate

import java.util.Arrays;
import java.util.List;

class ParallelStreamExample {
	public static void main(String[] args) {
		// create a list
		List<String> list = Arrays.asList("Hello ", "S", "T", "R", "E", "A", "M!");

		// using parallelStream()
		// method for parallel stream
		list.parallelStream().forEach(System.out::print);
	}
}


