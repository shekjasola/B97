package com.cts.ps;
// Java code to demonstrate Iterating in

import java.util.Arrays;
import java.util.List;

class ParallelStreamWithOrderedIteration {

	public static void main(String[] args) {
		// create a list
		List<String> list = Arrays.asList("Hello ", "S", "T", "R", "E", "A", "M!");

		// using parallelStream() method for parallel stream
		list.parallelStream().forEachOrdered(System.out::print);
	}
}
