package com.cts.ps;
// Java program to understand execution

import java.util.Arrays;
import java.util.List;

class SequentialStreamDemo {

	public static void main(String[] args) {
		// create a list
		List<String> list = Arrays.asList("Hello ", "S", "T", "R", "E", "A", "M!");

		// we are using stream() method
		// for sequential stream
		// Iterate and print each element
		// of the stream
		list.stream().forEach(System.out::print);
	}
}
