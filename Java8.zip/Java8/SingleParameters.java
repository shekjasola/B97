package com.cts.lambda;
interface Sayablex{  
    public String say(String name);  
}  
  
public class SingleParameters{  
    public static void main(String[] args) {  
      
        // Lambda expression with single parameter.  
        Sayablex s1=(name)->{  
            return "Hello, "+name;  
        };  
        System.out.println(s1.say("Vijay"));  
          
        // You can omit function parentheses    
        Sayablex s2= name ->{  
            return "Hello, "+name;  
        };  
        System.out.println(s2.say("Ravi"));  
    }  
}  