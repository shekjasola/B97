package com.cts.lambda;

interface Drawablex {
	public void draw();
}

public class WithoutLambda {
	public static void main(String[] args) {
		int width = 10;

		// without lambda, Drawable implementation using anonymous class
		Drawablex d = new Drawablex() {
			public void draw() {
				System.out.println("Drawing " + width);
			}
		};
		d.draw();
	}
}