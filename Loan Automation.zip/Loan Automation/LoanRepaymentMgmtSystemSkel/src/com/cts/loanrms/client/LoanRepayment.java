package com.cts.loanrms.client;


import java.util.Scanner;

import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.service.LoanRepaymentService;


public class LoanRepayment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// TYPE YOUR CODE HERE
	}

}
