package com.cts.loanrms.exception;

public class LoanRepaymentException extends Exception{
	
String strMsg1;
Throwable strMsg2;


public LoanRepaymentException() {
	super();
}


public LoanRepaymentException(String strMsg1, Throwable strMsg2) {
	super();
	this.strMsg1 = strMsg1;
	this.strMsg2 = strMsg2;
}

}
