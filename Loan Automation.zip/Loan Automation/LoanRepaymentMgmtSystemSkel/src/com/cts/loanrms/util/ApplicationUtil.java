package com.cts.loanrms.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import com.cts.loanrms.exception.LoanRepaymentException;







public class ApplicationUtil {


	public static List<String> readFile(String inputfeed) throws LoanRepaymentException {
		List<String> loanInstPytList = new ArrayList<String>();
		
		// TYPE YOUR CODE HERE

		return loanInstPytList;
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		
		// TYPE YOUR CODE HERE
		
		return sqlDate;
	}
	
	public static java.util.Date stringToDateConverter(String stringDate) {
		
		// TYPE YOUR CODE HERE
		
		return new Date();
	}
	
	public static boolean checkIfDateOfPytIsLessThanDueDate(Date dateOfPyt,Date dueDate)
	{
		//Date dtOPfyt,actDueDt;
		boolean eligibility=false;
		double difInMSeconds=0.0;
		double days=0.0;
		//Write the logic here to compare and see if the payment date is 20 days or more to due date
		
		
		
		return eligibility;
	}
}
