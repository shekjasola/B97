package com.cts.loanrms.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import com.cts.loanrms.dao.LoanInstallmtDAO;
import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.util.ApplicationUtil;

class LoanInstallmtDAOTest {

	private LoanInstallmtDAO loanInstlDao;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		loanInstlDao = new LoanInstallmtDAO();
	}

	@AfterEach
	void tearDown() throws Exception {
		loanInstlDao = null;
	}

	@Test
	void testInsertLoanInstallmentPyt() {
		ArrayList <LoanInstallmentPyt> loanInstlPytList = new ArrayList<LoanInstallmentPyt> ();
		loanInstlPytList.add(new LoanInstallmentPyt("P001","C001","L001","KeerthiKumar","HousingLoan",20345,ApplicationUtil.stringToDateConverter("2020-01-25"),ApplicationUtil.stringToDateConverter("2020-01-04"),18311,2000000));
		loanInstlPytList.add(new LoanInstallmentPyt("P002","C002","L002","KumarMartha","HousingLoan",33350,ApplicationUtil.stringToDateConverter("2020-02-28"),ApplicationUtil.stringToDateConverter("2020-02-07"),29348,3000000));
		loanInstlPytList.add(new LoanInstallmentPyt("P003","C003","L003","MaheshKumar","VehicleLoan",13000,ApplicationUtil.stringToDateConverter("2020-01-30"),ApplicationUtil.stringToDateConverter("2020-01-05"),11440,1200000));
		loanInstlPytList.add(new LoanInstallmentPyt("P004","C004","L004","RajeshKumar","EducationalLoan",7500,ApplicationUtil.stringToDateConverter("2020-02-20"),ApplicationUtil.stringToDateConverter("2020-01-25"),6600,800000));
		loanInstlPytList.add(new LoanInstallmentPyt("P005","C005","L005","Rakesh","HousingLoan",25800,ApplicationUtil.stringToDateConverter("2020-03-25"),ApplicationUtil.stringToDateConverter("2020-03-04"),23220,2500000));
		loanInstlPytList.add(new LoanInstallmentPyt("P006","C006","L006","Sudarshan","PersonalLoan",9400,ApplicationUtil.stringToDateConverter("2020-01-25"),ApplicationUtil.stringToDateConverter("2020-01-01"),8272,800000));
		try {
		if(loanInstlDao.insertLoanInstallmentPyt(loanInstlPytList))
		{
			assertTrue(true);
		}
		else {
			fail("Data not persisted into the DB/records already exists by default in DB");
		}
		
		} catch (LoanRepaymentException e) {
			// TODO Auto-generated catch block
			fail("Issue while saving DB/records already exists by default");
			e.printStackTrace();
		}
	}

	/*
	@Test
	void testGetLoanInstallmentPytData() {
		fail("Not yet implemented");
	}*/

}
