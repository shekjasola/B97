package com.cts.loanrms.dbcon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.loanrms.dao.DBConnectionManager;
import com.cts.loanrms.exception.LoanRepaymentException;

class DBConnectionManagerTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	/*
	@Test
	void testDBConnectionManager() {
		fail("Not yet implemented");
	}

	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}*/

	@Test
	void testGetConnection() {
		try 
		{
			if(DBConnectionManager.getInstance()!=null && DBConnectionManager.getInstance().getConnection()!=null)
			{
				assertTrue(true);
			}
			else
			{
				fail("Please check if the DB connection is implemented correctly");
			}
		} catch (LoanRepaymentException e) {
			// TODO Auto-generated catch block
			fail("Please check if the DB connection is implemented correctly");
			e.printStackTrace();
		}
		
	}

}
