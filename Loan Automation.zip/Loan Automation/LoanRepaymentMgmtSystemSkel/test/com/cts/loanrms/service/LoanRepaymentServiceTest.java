package com.cts.loanrms.service;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import com.cts.loanrms.dao.DBConnectionManager;
import com.cts.loanrms.dao.LoanInstallmtDAO;
import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.service.LoanRepaymentService;
import com.cts.loanrms.util.ApplicationUtil;

class LoanRepaymentServiceTest {

LoanRepaymentService loanRepytService = null;
	
	LoanInstallmtDAO loanInstDao = null;
	ArrayList<LoanInstallmentPyt> loanPytList = null;
	String fileName;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		loanRepytService = new LoanRepaymentService();
		fileName="resources\\inputfeed.txt";
		loanInstDao = new LoanInstallmtDAO();
		loanPytList = new ArrayList<LoanInstallmentPyt>();
		
		loanPytList.add(new LoanInstallmentPyt("P001","C001","L001","KeerthiKumar","HousingLoan",20345,ApplicationUtil.stringToDateConverter("2020-01-25"),ApplicationUtil.stringToDateConverter("2020-01-04"),18311,2000000));
		loanPytList.add(new LoanInstallmentPyt("P002","C002","L002","KumarMartha","HousingLoan",33350,ApplicationUtil.stringToDateConverter("2020-02-28"),ApplicationUtil.stringToDateConverter("2020-02-07"),29348,3000000));
		loanPytList.add(new LoanInstallmentPyt("P003","C003","L003","MaheshKumar","VehicleLoan",13000,ApplicationUtil.stringToDateConverter("2020-01-30"),ApplicationUtil.stringToDateConverter("2020-01-05"),11440,1200000));
		loanPytList.add(new LoanInstallmentPyt("P004","C004","L004","RajeshKumar","EducationalLoan",7500,ApplicationUtil.stringToDateConverter("2020-02-20"),ApplicationUtil.stringToDateConverter("2020-01-25"),6600,800000));
		loanPytList.add(new LoanInstallmentPyt("P005","C005","L005","Rakesh","HousingLoan",25800,ApplicationUtil.stringToDateConverter("2020-03-25"),ApplicationUtil.stringToDateConverter("2020-03-04"),23220,2500000));
		loanPytList.add(new LoanInstallmentPyt("P006","C006","L006","Sudarshan","PersonalLoan",9400,ApplicationUtil.stringToDateConverter("2020-01-25"),ApplicationUtil.stringToDateConverter("2020-01-01"),8272,800000));
		
	}

	@AfterEach
	void tearDown() throws Exception {
		loanRepytService = null;
	}

	@Test
	void testBuildLoanInstallmentPytList() {
	
		try {
			List <String> loanPytStrRecords = ApplicationUtil.readFile(fileName);
			ArrayList<LoanInstallmentPyt> loanPytRecords = null;
			boolean isRecordsRetrieved = false;
			
			if (loanPytStrRecords.size() > 0) {
				isRecordsRetrieved = true;
				loanPytRecords = loanRepytService.buildLoanInstallmentPytList(loanPytStrRecords);
			}
			if (isRecordsRetrieved) {
				if (loanPytRecords.size() > 0) {
					
					List <String> actualLoanList = loanPytRecords.stream().map(Object::toString).collect(Collectors.toList());
					List <String> expectedList = loanPytList.stream().map(Object::toString).collect(Collectors.toList());
					
					assertEquals(actualLoanList,expectedList);
					
				} else {
					fail("Loan Installment Pyt list Not Created Properly");
				}
			}
			else
			{
				fail("Problem in reading data from CSV File");
			}
		}
		catch(Exception e)
		{
			fail("Build LoanInstallmentPytList() method failed , please check the custom exception LoanRepaymentException "+e.getCause());
		}
		
		
	}

	@Test
	void testAddLoanInstallmentPytDetails() {
		try
		{
			List <String> loanPytStrRecords = ApplicationUtil.readFile(fileName);
			ArrayList<LoanInstallmentPyt> loanPytRecords = null;
			boolean isRecordsRetrieved = false;
			boolean isInserted = false;
			if (loanPytStrRecords.size() > 0) {
				isRecordsRetrieved = true;
				loanPytRecords = loanRepytService.buildLoanInstallmentPytList(loanPytStrRecords);
			}
			if (isRecordsRetrieved) {
				if (loanPytRecords.size() > 0) {
					if (loanInstDao.insertLoanInstallmentPyt(loanPytRecords)) {
						isInserted = true;
					}
				}
			}
			if (isRecordsRetrieved && isInserted) {
				assertTrue(isRecordsRetrieved);
				assertTrue(isInserted);
			} else if (isRecordsRetrieved && !isInserted) {
				assertTrue(isRecordsRetrieved);
				assertFalse(isInserted);
			} else {
				fail("Error in inserting Loan Installment Repayment details");
			}
		}
		catch(Exception e)
		{
			fail("AddLoanInstallmentPytDetails method failed please check the custom exception LoanRepaymentException "+e.getCause());
		}
	}
	/**/
	
	@Test
	void testCalculateDiscountedInstallment() {
		
		double expectedDiscInstlmt=11440.0;
		double actualDiscInstlmt=0.0;
		double loanAmount,currentInstallmentAmt=0.0;
		double revisedInstallment=0.0;
		String loanType;
		try
		{
			List <String> loanPytStrRecords = ApplicationUtil.readFile(fileName);
			ArrayList<LoanInstallmentPyt> loanPytRecords = null;
			boolean isRecordsRetrieved = false;
			boolean isInserted = false;
			if (loanPytStrRecords.size() > 0) {
				isRecordsRetrieved = true;
				loanPytRecords = loanRepytService.buildLoanInstallmentPytList(loanPytStrRecords);
			}
			if(isRecordsRetrieved) 
			{
				loanType = loanPytRecords.get(0).getLoanType();
				loanAmount = loanPytRecords.get(0).getLoanAmount();
				currentInstallmentAmt = loanPytRecords.get(0).getInstallmentAmtInRs();
				
				revisedInstallment = loanRepytService.calculateDiscountedInstallment(loanType, loanAmount, currentInstallmentAmt);
				
			}
				if((revisedInstallment == 18311))
				{
					assertEquals(revisedInstallment,18311.0);
					
				}
				else
				{
					fail("CalculateDiscountedInstallment Method failed to calculate Discounted Loan Amt accurately");
				}
			
		}
		catch(Exception e)
		{
			fail("testCalculateDiscountedInstallment method failed please check the custom exception LoanRepaymentException"+e.getCause());
		}
		
	}/**/
	
	@Test
	void testGetConnection() {
		
		Connection con;
		try 
		{
			con = DBConnectionManager.getInstance().getConnection();
			if(con!=null)
			{
				assertNotNull(con);
			}
			else
			{
				fail("Connection Failed");
			}
		} 
		catch (LoanRepaymentException e) {
			// TODO Auto-generated catch block
			fail("Connection Exception "+e.getCause());
		}
		catch(NullPointerException exp)
		{
			fail("Connection Failed");
		}
		
		
	}

}
