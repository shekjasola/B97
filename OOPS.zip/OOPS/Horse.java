package com.b97.oops;



class Animal{
	
	public void run() {
		System.out.println("animal is running");
	}
}



public class Horse extends Animal{

	public void run() {
		System.out.println("Horse is running");
	}
	public static void main(String[] args) {
		
		/*
		 * Animal a1= new Animal();//run a1.run(); Horse h1= new Horse(); h1.run();
		 */
		
		// Upcasting
		
		Animal a2= new Horse();
		a2.run();
		
		//downcasting
		Horse h1= (Horse) new Animal();
		h1.run();
	}
}