package com.b97.oops;

//Super class//Parent class/Base class
class Car {

	//instance variable
	String color = "Blue";
// instance method
	public void getMilage() {
		System.out.println("15KMPL");
	}
}

//Sub class/child class/derived class
//SL keyword-extends
class Hyundai extends Car { // IS-A

	 public void maxSpeed() {
		 System.out.println("180KMPH");
	 }
}

class Venue extends Hyundai{
	//code reusabilty ML
	public void getDrive() {
		System.out.println("cool");
	}
	
}
public class InheritanceEx {

	public static void main(String[] args) {
		Venue v1= new Venue();
		v1.getMilage();//inherited from Car class
		v1.maxSpeed();//inherited from Hyundai
		System.out.println(v1.color);//inherited from Car class
		v1.getDrive();

	}

}
