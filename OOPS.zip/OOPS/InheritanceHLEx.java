package com.b97.oops;

//Super class
class Cars
{
	
	String color="BlackForest";
	
	public void getMilage() {
		System.out.println("20KMPL");
	}
}

//Sub class
class BMW extends Cars{
	
}

//Sub class
class Audi extends Cars{
	
}


public class InheritanceHLEx {

	public static void main(String[] args) {
	
		BMW b1= new BMW();
		b1.getMilage();
		System.out.println("Color of BMW "+ b1.color);
		
		Audi a1 = new Audi();
		a1.getMilage();
		System.out.println("Color of Audi "+ a1.color);

	}

}
