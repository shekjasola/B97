package com.b97.oops;

public class OverloadingEx {

	public int sum(int x, int y) {
		System.out.println(x + y);
		return x + y;

	}

	private int sum(int x, int y, int z) {
		System.out.println(x + y + z);
		return x + y + z;

	}

	public float sum(float x, float y) {
		System.out.println(x + y);
		return x + y;

	}

	public double sum(double x, double y) {
		System.out.println(x + y);
		return x + y;

	}

	public static void main(String[] args) {
		
		OverloadingEx e1= new OverloadingEx();
		e1.sum(20.8f, 30.9F);//compile type

	}

}
