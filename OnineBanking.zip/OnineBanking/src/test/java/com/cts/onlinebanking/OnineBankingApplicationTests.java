package com.cts.onlinebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnineBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
