package com.cts.inheritance;
public class Employee extends Person{
 
    int employeeNumber;
 
    public int getEmployeeNumber() {
        return employeeNumber;
    }
 
    public void setEmployeeNumber(int employeeNumber) {
        this.employeeNumber = employeeNumber;
    }
    
    
 
}