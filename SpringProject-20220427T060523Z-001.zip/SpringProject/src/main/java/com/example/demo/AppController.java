package com.example.demo;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes({"name"})
public class AppController {
	
	@Autowired
	EmployeeDao empDao;
	
	
	@GetMapping("/")
	public String showLogin() {
		
		
		return "login";  // /view/login.jsp
		
	}
	
	@InitBinder
	public void formBinder(WebDataBinder dataBinder) {
		
		StringTrimmerEditor stringTrimmer=new StringTrimmerEditor(true);
		
		dataBinder.registerCustomEditor(String.class, stringTrimmer);
		
		DateFormat df=new SimpleDateFormat("yyyy-MM-dd");
		
		CustomDateEditor dateEditor=new CustomDateEditor(df, true);
		
		dataBinder.registerCustomEditor(Date.class,dateEditor);
		
		
		
		
	}
	
	@ModelAttribute("desg")
	public Map<String,String> getDesignation(){
		
		Map<String,String> map=new HashMap<String,String>();
		
		map.put("prg","programmer");
		map.put("tester", "tester");
		map.put("analyst", "analyst");
		map.put("accounts", "accounts");
		
		return map;
		
		
	}
	
	
	@PostMapping("validate")
	public String validateUser(@RequestParam String username,@RequestParam String password,Model model) {
		
		System.out.println(username +"   "+password);
		
		if(username.equals("abc") && password.equals("1234")) {
			
			model.addAttribute("name", username);
			
			return "home";
		}else {
			return "login";
		}
		
		
		
	}
	
	@GetMapping("register")
	public String showRegister(@ModelAttribute Employee employee) {
		
		return "register";
		
	}
	
	@PostMapping("regEmployee")
	public String registerEmp(@Valid @ModelAttribute Employee employee, BindingResult result) {
		
		if(result.hasErrors()) {
			
			System.out.println(result.getFieldError());
			
			return "register";
		}
		
		empDao.registerEmp(employee);
		
		System.out.println(employee);
		
		return "home";
		
	}
	
	@GetMapping("showAll")
	public ModelAndView showAllEmp() {
		
		ModelAndView mv=new ModelAndView("showAll");
		List<Employee> list=empDao.getAllEmp();
		
		mv.addObject("empList",list);
			
		return mv;
	}
	
	@GetMapping("delete")
	public String deleteEmp(@RequestParam int id) {
		
		System.out.println("delete emp "+id);
		
		empDao.deleteEmp(id);
		
		return "redirect:showAll";
		
	}
	
	
	@GetMapping("findEmp")
	public String findEmp(Model model) {
		
		model.addAttribute("findForm","findForm");
		
		
		return "home";
		
	}
	
	
	@GetMapping("empFind")
	public String findEmp(@RequestParam int id, Model model) {
		
		model.addAttribute("emp", empDao.findEmp(id));
		
		
		return "home";
		
	}
	

	
	
	

}
