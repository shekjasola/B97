package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDao {
	
	
	
	@Autowired
	EmployeeRepository empRepo;
	
	public void registerEmp(Employee emp) {
		
		empRepo.save(emp);
		
		
	}
	
	public List<Employee> getAllEmp() {
		
	   return empRepo.findAll();
			
	
		
		
	}
	
	
	public void deleteEmp(int id) {
		
	  empRepo.deleteById(id);
		
	}
	
	public Employee findEmp(int id) {
		
		return empRepo.findById(id).get();
		
		
	}
	
	

}
