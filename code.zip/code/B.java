package com.b97.oops;

public class B {

	public static void main(String[] args) {
		
		A a1= new A();
		a1.setName("Venkat");
		a1.setAge(21);
		System.out.println("Name "+ a1.getName());
		System.out.println("Age :"+ a1.getAge());
	
		

	}

}
