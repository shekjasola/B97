package com.b97.oops;

public class C {

	public static void main(String[] args) {
		A a1= new A();
		a1.setName("Sai");
		a1.setAge(22);
		System.out.println("Name "+ a1.getName());
		System.out.println("Age :"+ a1.getAge());

	}

}
