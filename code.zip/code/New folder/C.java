package com.b97.second;

import com.b97.first.A;

 class C {

	
	  public static void main(String[] args) {
		  A a2 = new A();
	  
	 // System.out.println(a2.age);
	  
	  }
	

}

