package com.cts.strings;

class TestStringConcatenation2 {
	public static void main(String args[]) {
		
		String course = "FCC";
		System.out.println(course instanceof Object);
		
		
		String s = 50 + 30 + "Sachin" + (40 + 40);
		System.out.println(s);
	}
}