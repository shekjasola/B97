package com.cts.strings;

public class TestSubstring {
	public static void main(String args[]) {
		String s = "Sachin Tendulkar";
		System.out.println(s.substring(6));// Tendulkar
		System.out.println(s.substring(0, 4));// Sachin
	}
}