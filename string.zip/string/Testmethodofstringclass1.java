package com.cts.strings;

public class Testmethodofstringclass1 {
	public static void main(String args[]) {

		String s = "  Sachin  ";
		System.out.println(s);// Sachin
		System.out.println(s.trim());// Sachin
	}
}