package com.cts.strings;

public class Testmethodofstringclass3 {
	public static void main(String args[]) {

		String s = "Sachin";
		System.out.println(s.charAt(0));// S
		System.out.println(s.charAt(3));// h
	}
}