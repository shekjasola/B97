package com.cts.strings;
public class Testmethodofstringclass4{
 public static void main(String args[]){
 
   String s="Sachin";
   System.out.println(s.length());//6
  }
}
